// tslint:disable-next-line:class-name
export class digital {
    id: any;
    FileType: string;
    FilePages: any;
    FileSize: any;
    CurrentApprover: string;
    ApprovedOn: Date | string | null;
 }